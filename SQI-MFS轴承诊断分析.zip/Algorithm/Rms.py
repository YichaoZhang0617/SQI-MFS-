#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#project :
#Author :Xiaochao
import math

def Rms(data,N):
    if isinstance(data,list):
        pass
    else:
        # 转换为list类型
        data = data.tolist()
    count = 0
    for i in range(N-1):
        square = data[i] * data[i]
        count = count + square
    # count 表示原始振动数据平方之和
    RMS = math.sqrt(count / (N-1))
    return RMS