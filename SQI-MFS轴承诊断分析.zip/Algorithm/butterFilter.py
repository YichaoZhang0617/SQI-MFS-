#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#project :
#Author :Xiaochao

from scipy import signal

def butterFilter(data,featureValue,BandPassFrequency):
    #滤波阶数
    n = 4
    # 采样频率
    sampleRate = int(featureValue[0])
    # 截止频率，注意str类型经分割处理后变成list类型
    BandPassFrequency = BandPassFrequency.split(',')
    small = int(BandPassFrequency[0])
    big = int(BandPassFrequency[2])
    # wn1 和  wn2 （当wn1为0时，只能进行低通滤波）
    wn1 = 2 * small / sampleRate
    wn2= 2 * big / sampleRate
    if wn1 == 0.0:
        [b, a] = signal.butter(n, wn2, "lowpass")
    else:
        [b, a] = signal.butter(n, [wn1,wn2], "bandpass")
    # # 将list类型里面的每一个list转换为float类型
    # datas = []
    # for k in data:
    #     datas.append(float(k[0]))
    signal_Filter = signal.filtfilt(b, a, data)
    return signal_Filter