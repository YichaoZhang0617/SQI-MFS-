#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#project :
#Author :Xiaochao

from Algorithm.Rms import Rms
import numpy as np
from scipy.fftpack import fft

def featureAndvalue(data,select):

    # 将list中的数字类型提取出来
    count = []
    for i in data:
        count.append(float(i[0]))
    data = count

    N = len(data)
    # 时域的RMS值
    rms = Rms(data, N)
    rms = float('%.6f' % rms)
    # 时域的MAX
    maxs = max(data)
    maxs = float('%.6f' % maxs)
    # 时域的MEAN
    mean = np.mean(data)
    mean = float('%.6f' % mean)
    # 时域的STD
    std = np.std(data)
    std = float('%.6f' % std)

    # 对整体信号进行傅里叶变换，并取RMS和Peak
    y1 = fft(data, N)
    mag = abs(y1)
    # 对傅里叶变换后幅值取FFTRMS和Peak
    # 频域的RMS值
    fftrms = Rms(mag, N)
    fftrms = float('%.6f' % fftrms)
    # 求傅里叶变换后的峰值
    peak = max(mag)
    peak = float('%.6f' % peak)

    dict = {'rms': rms, 'max': maxs, 'mean': mean, 'std': std, 'fftrms': fftrms, 'peak': peak}
    zidian = []
    # select是字符串，需要先转换为列表类型
    select = select.split(',')
    for key in select:
        zidian.append(str(key) + ":" + str(dict[key]))

    return zidian