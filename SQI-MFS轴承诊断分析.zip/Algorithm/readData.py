#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#project :
#Author :Xiaochao
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#project :
#Author :Xiaochao

def readData(data,t):
    # data是ndarray类型
    # data = data.tolist()
    # 取振动值
    value = []
    if t==0:
        for v in data:
            vv = v[1:2]
            value.append(vv)
    else:
        for v in data:
            vv = v[0:1]
            value.append(vv)
    return  value