#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#project :
#Author :Xiaochao
from scipy.fftpack import fft
def realtimeplot(data, sampleRate):

    # 采样频率
    fs = int(sampleRate)
    N = len(data)
    # 对数据进行傅里叶变换
    # 将list 里面的 str转换成float类型(注意这里str类型也不会报错，一定要注意数据类型)
    yss = []
    for j in data:
        yss.append(float(j[0]))
    data = yss
    y = fft(data)
    # 求得傅里叶变换后的振幅
    mag = abs(y)
    # 频域序列
    fftrms = []
    # 注意这里的采样频率由原始数据的多少决定
    for k in range(N):
        ff = k * fs / N
        ff = float('%.3f' % ff)
        fftrms.append(ff)
    xx = fftrms
    yy = mag.tolist()
    return xx,yy