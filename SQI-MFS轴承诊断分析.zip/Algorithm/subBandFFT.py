#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#project :
#Author :Xiaochao

import numpy as np
from Algorithm.Rms import Rms
from scipy.fftpack import fft

def subBandFFT(data,samplatesize,featureValue,BandPassFrequency,choose):
    # 对数据进行傅里叶变换，然后分频段取最大值或平均值，如果BandPassFrequency输入为[0,10,200]，那么FFT后的频率段应为[0-200]
    # 且每10Hz分为一个小区间，取其幅值的最大值或平均值
    # 截止频率，注意str类型经分割处理后变成list类型
    BandPassFrequency = BandPassFrequency.split(',')
    start = int(BandPassFrequency[0])
    subBand = int(BandPassFrequency[1])
    end = int(BandPassFrequency[2])
    # 采样频率
    sampleRate = int(featureValue[0])
    # 求得傅里叶变换后的振幅
    y = fft(data)
    yy = abs(y)
    # 频域序列
    fftrms = []
    # 注意这里的采样频率由原始数据的多少决定
    for k in range(samplatesize):
        ff = k * sampleRate / samplatesize
        fftrms.append(ff)
    # 直接算出来的fftrms为[0-sampleRate]，只取滤波段为[0-200]的，其余的删掉
    f = []
    for j in fftrms:
        if j < end:
            f.append(j)
        else:
            break
    # 将取出的频率分组，分为(end-start)/subBand 组
    zu = int((end-start)/subBand)
    # 每组有len(f)/zu个
    number = int(len(f)/zu)
    a = 0
    count = []
    Hz = 0
    for q in range(zu):
        values = yy[number * a:number * (a + 1) - 1]
        # 取最大值、最小值、RMS值或平均值
        if choose=="max":
            value = max(values)
        elif choose=="min":
            value = min(values)
        elif choose=="rms":
            value = Rms(values,number)
        else:
            value = np.mean(values)
        Hz = Hz + 10
        counts = [Hz, value]
        count.append(counts)
        a = a + 1
    return count