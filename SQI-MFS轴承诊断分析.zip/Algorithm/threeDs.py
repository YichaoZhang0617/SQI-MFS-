#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#project :
#Author :Xiaochao
import math
from Algorithm.butterFilter import butterFilter
from Algorithm.subBandFFT import subBandFFT

def threeDs(data,featureValue,BandPassFrequency,samplatesize,choose):
    if isinstance(data,list):
        pass
    else:
        # 转换为list类型
        data = data.tolist()
    value = []
    for i in data:
        c = i[1:2]
        value.append(float(c[0]))
    # samplate = featureValue[0]
    N = len(value)
    samplatesize = int(samplatesize)
    # 原始数据分为number组
    number = math.ceil(N / samplatesize)
    count = []
    a = 0
    for q in range(number):
        # 一、对原始数据进行分组
        xx = value[samplatesize * a:samplatesize * (a + 1) - 1]
        # 二、带通滤波处理
        signal_Filte = butterFilter(xx,featureValue,BandPassFrequency)
        # 三、对数据进行傅里叶变换，然后分频段取最大值或平均值
        count2 = subBandFFT(signal_Filte,samplatesize,featureValue,BandPassFrequency,choose)
        # 四、对所得到的频率段值和特征值汇总
        # count1 = [q,count2]
        count.append(count2)
        a = a + 1

    return number,count