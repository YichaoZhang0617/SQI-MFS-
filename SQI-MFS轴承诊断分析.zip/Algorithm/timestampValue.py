#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#project :
#Author :Xiaochao

def timestampValue(data):
    # 取时间戳
    timestamp = []
    for v in data:
        vv = v[0:1]
        timestamp.append(vv)
    # 取振动值
    value = []
    for v in data:
        vv = v[1:2]
        value.append(vv)
    # 将list类型里面的每一个list转换为float类型(读取前2000个数据)
    data = []
    for k in timestamp:
        data.append(float(k[0]))
    vv = []
    for k in value:
        vv.append(float(k[0]))
    return data,vv