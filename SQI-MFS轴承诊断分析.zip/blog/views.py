from django.shortcuts import render, HttpResponse
from Algorithm.timestampValue import timestampValue
from Algorithm.realtimeplot import realtimeplot
from Algorithm.featureAndvalue import featureAndvalue
from django.views.decorators.csrf import csrf_exempt
from Algorithm.threeDs import threeDs
import scipy.io
import json
import time
import random
import numpy as np


# 定义全局变量的方式(必须先在函数外部定义，然后声明global是全局变量，就可以改变其值了)
# root 表示文件路径
root = []
# judge区分本地还是Demo数据
judge = 0
# featureValue 表示local采样频率、电机转速、纵坐标值
featureValue = []
# configure 表示Demo采样频率、电机转速、纵坐标值
configure = []
# 定义全局变量，用于获取本地文件数据
localData = []
# 定义全局变量，用于获取Demo数据
bendiData = []
# t表示对数据源的划分，如果是t=0，表示是NASA和SQI数据集，读取.mat文件的第二个字符；如果是CWRU数据集，读取.mat文件的第一个字符
t = 0
# 定义全局变量change表示所选取的Demo的故障类型
change1 = []
# 定义全局变量local表示所选取的Local的故障类型
change3 = []

@csrf_exempt
def datasource(request):
    global root
    root = 'C:\\Users\\Chao\\Desktop\\python项目\\Django\\jianshu\\source'
    return render(request, 'datasource.html')

def xiaochao(request):
    global root
    root = 'C:\\Users\\Chao\\Desktop\\python项目\\Django\\jianshu\\source'
    return render(request, 'xiaochao.html')

def localdata(request):
    local = 'C:\\Users\\Chao\\Desktop\\python项目\\Django\\jianshu\\source'
    # 其中a表示读取的文件名;b表示是否有时间戳;c表示采样频率;d表示电机转速;e表示纵坐标单位;f表示是否进行傅里叶变换
    a = request.GET['a']
    b = request.GET['b']
    c = request.GET['c']
    d = request.GET['d']
    e = request.GET['e']

    global change3
    change3 = a
    # 判断是否有时间戳,如果有，读取源文件中两列数据；如果没有，读取一列数据
    file = open(local + "\\" + a)
    lists = []
    for line in file:
        aa = line.split()
        if b == "true":
            bb = aa[0:2]
        else:
            bb = aa[0:1]
        lists.append(bb)
    file.close()
    # lists 是list类型，['0','1']
    k = len(lists)
    global localData
    # 如果有时间戳，转换为ndarray类型，直接绘制表格；如果没有，添加一列时间戳
    if b == "true":
        localData = np.array(lists)
    # 如果没有，新增时间戳一列,新增的时间戳的计算公式为1/samplerate
    else:
        time = []
        o = 0
        for j in range(k):
            o = o + 1/float(c)
            o = float('%.4f' % o)
            time.append([o])
        # 将lists转换为 ndarray 类型
        data = np.array(lists)
        localData = np.hstack((time, data))
    global featureValue
    featureValue = [c,d,e]
    global judge
    judge = 1
    r = HttpResponse("The Data is Read!")
    return r

def demodata(request):

    # 其中g表示选取的Demo数据源;h表示选取的故障类型
    g = request.GET['g']
    h = request.GET['h']

    global root
    # 读取选取的数据文件
    sourcedata = root + "\\" + g
    # 判断数据源类型，如果是 CWRU 数据源，需要先读取数据补充时间戳值
    data = scipy.io.loadmat(sourcedata)
    # 其中t表示对数据源的划分，如果是t=0，表示是NASA和SQI数据集，读取.mat文件的第二个字符；如果是CWRU数据集，读取.mat文件的第一个字符
    global t
    if g == 'CWRU(DE)':
        t = 1
        if h == 'Health(1796&12KHz)':
            # Health
            datatype = data['X097_DE_time']
        elif h == 'Outer(0.007-1-&1773&12KHz)':
            # Inner
            datatype = data['X106_DE_time']
        elif h == 'Inner(0.007-1-&1772&12KHz)':
            # Ball
            datatype = data['X119_DE_time']
        else:
            # Outer
            datatype = data['X131_DE_time']
        # datatype是读取的原始数据类型，由于数据点较多，频率为12K，每100个点取一个点
        lists = []
        select = []
        i = 1
        k = 0
        for array in datatype:
            p = array[0:1]
            lists.append(p)
            if (i % 100 == 0):
                slice = random.sample(lists, 1)
                slices = float('%.3f' % slice[0][0])
                select.append([slices])
                lists = []
                i = 1
                k = k + 1
            else:
                i = i + 1
        # 将select转换为 ndarray 类型
        data = np.array(select)
        # 其中select是挑选出来的时域值，新增时间戳一列
        time = []
        o = 0
        for j in range(k):
            o = o + 0.0083
            o = float('%.4f' % o)
            time.append([o])
        datatype = np.hstack((time, data))
        # 由于每组数据的采样频率、电机转速以及纵坐标单位
        sampleRate = 12000
        motor = 120
        label = '加速度:g'
    elif g == 'NASA(bearing1-Ch1)':
        if h == 'Step1(2000&20KHz)':
            # 第一阶段
            datatype = data['step1']
        elif h == 'Step2(2000&20KHz)':
            # 第二阶段
            datatype = data['step2']
        elif h == 'Step3(2000&20KHz)':
            # 第三阶段
            datatype = data['step3']
        else:
            # 第四阶段
            datatype = data['step4']
        # 由于每组数据的采样频率、电机转速以及纵坐标单位
        sampleRate = 1
        motor = 120
        label = '加速度:g'
    else:
        if h == 'Health(20Hz&10KHz)':
            # health
            datatype = data['OneLoad20HzNoBeltHealth']
        elif h == 'Inner(20Hz&10KHz)':
            # Inner
            datatype = data['OneLoad20HzNoBeltInner']
        elif h == 'Outer(20Hz&10KHz)':
            # Outer
            datatype = data['OneLoad20HzNoBeltOuter']
        else:
            # Ball
            datatype = data['OneLoad20HzNoBeltBall']
        # 由于每组数据的采样频率、电机转速以及纵坐标单位
        sampleRate = 12800
        motor = 120
        label = '加速度:g'
    global bendiData,configure
    configure = [sampleRate,motor,label]
    # 其中bendiData已经包含时间戳和震荡值两列,转换为ndarray类型
    bendiData = np.array(datatype)
    # 返回原始数据源+故障类型
    global change1
    change1 = g + "+" + h
    r = HttpResponse(change1)
    return r

def feature(request):
    # 其中i表示选取的特征
    i = request.GET['i']

    # 判断是本地数据还是Demo数据
    global judge
    if judge == 1:
        global localData,featureValue
        data = localData
    else:
        global bendiData,configure
        data = bendiData
    if isinstance(data,list):
        pass
    else:
        # 转换为list类型
        data = data.tolist()
    # 读取选取的特征值,表示读取震荡值那一列，必须统一都传入list类型数据
    # 取震荡加速度
    mg = []
    for v in data:
        vv = v[1:2]
        mg.append(vv)
    zidian = featureAndvalue(mg,i)

    # 将读到的特征转换为json格式（特征值数据）
    jsondata = {"feature": zidian}
    jsondata = json.dumps(jsondata)
    r = HttpResponse(jsondata)
    return r

# 当选择Demo时，前端显示选择的Demo数据及故障类型
def change(request):
    m = request.GET['m']
    # 延时一秒钟，保证change1、change2的值改变后再执行下面的程序
    time.sleep(1)
    global change1,change2
    if change2 == "0":
        m = 'Health(20Hz&10KHz)'
    elif change2 == "1":
        m = 'Inner(20Hz&10KHz)'
    elif change2 == "2":
        m = 'Outer(20Hz&10KHz)'
    elif change2 == "3":
        m = 'Ball(20Hz&10KHz)'
    elif change2 == "4":
        m = 'Step1(2000&20KHz)'
    elif change2 == "5":
        m = 'Step2(2000&20KHz)'
    elif change2 == "6":
        m = 'Step3(2000&20KHz)'
    elif change2 == "7":
        m = 'Step4(2000&20KHz)'
    elif change2 == "8":
        m = 'Health(1796&12KHz)'
    elif change2 == "9":
        m = 'Outer(0.007-1-&1773&12KHz)'
    elif change2 == "10":
        m = 'Inner(0.007-1-&1772&12KHz)'
    else:
        m ='Ball(0.007-1-&1772&12KHz)'

    change1 = change1 + "+" + m
    r = HttpResponse(change)
    return r

def localchange(request):
    m = request.GET['m']
    # 延时一秒钟，保证change3的值改变后再执行下面的程序
    time.sleep(1)
    global change3
    m = change3
    r = HttpResponse(m)
    return r

def bar3d(request):
    m = request.GET["m"]
    n = request.GET["n"]
    o = request.GET["o"]
    # 判断是本地数据还是Demo数据
    global judge
    if judge == 1:
        global localData, featureValue
        data = localData
        fv = featureValue
    else:
        global bendiData, configure
        data = bendiData
        fv = configure
    number,count = threeDs(data,fv,m,n,o)   # 表示先分段，然后分别求FFT
    # count是由两层list组成，须一步步解析出来
    y = []
    z = []
    for i in count:
        # 两层list
        for j in i:
            y.append(j[0])
            z.append(j[1])
    # 采样频率和最大幅值
    Frequencydomain = y
    Acceleration = z
    Max = int(max(Acceleration)+1)
    Min = min(Acceleration)

    print(max(Acceleration))
    print(min(Acceleration))
    # 将读到的数据转换为json格式
    jsondata = {"x": Frequencydomain,"y": Acceleration,"z": number,"Max": Max,"Min": Min}
    jsondata = json.dumps(jsondata)
    r = HttpResponse(jsondata)
    return r

def times(request):
    # 其中i表示选取的绘图方式
    i = request.GET['i']

    # 判断是本地数据还是Demo数据
    global judge
    if judge == 1:
        global localData, featureValue
        data = localData
        fv = featureValue
    else:
        global bendiData, configure
        data = bendiData
        fv = configure
    if isinstance(data, list):
        pass
    else:
        # 转换为list类型
        data = data.tolist()
    # 表示读取震荡值那一列，必须统一都传入list类型数据
    # 判断绘制时域或频域图
    if i == "Time":
        # 读取时间戳和震荡值
        [x, y] = timestampValue(data)
        legend = "Time domain map"
        xlabel = "时间：t/s"
    else:
        # 取震荡加速度
        mg = []
        for v in data:
            vv = v[1:2]
            mg.append(vv)
        [x, y] = realtimeplot(mg, fv[0])
        legend = "Frequency domain diagram"
        xlabel = "频域：f/Hz"

    ylabel = fv[2]
    # 如果点数太多，提取前200000个数据即可
    if len(x) > 200000:
        x = x[0:200000]
        y = y[0:200000]
    else:
        pass
    # 将读到的数据转换为json格式（特征值数据+提取的数据+图例+坐标轴）
    jsondata = {"x": x, "y": y, "legend": legend, "xlabel": xlabel, "ylabel": ylabel}
    jsondata = json.dumps(jsondata)
    r = HttpResponse(jsondata)
    return r






