"""jianshu URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from blog import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('datasource/',views.datasource), # Home页面
    path('localdata/',views.localdata),  # 读取本地文件数据
    path('demodata/',views.demodata),    # 读取Demo原始数据
    path('feature/', views.feature),   # 表示local选取特征
    path('times/', views.times),   # 表示选取的时域或频域，然后绘图
    path('change/', views.change),   # 表示local选取FFT，然后绘图
    path('localchange/',views.localchange),  # 前端显示选取的原始数据值
    path('bar3d/',views.bar3d),   # 绘制 3D 图
    path('xiaochaoui/',views.xiaochao),   # UI界面设计

]
