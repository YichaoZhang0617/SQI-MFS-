// 主页面的函数，导航键
$(function () {
    //超过一定高度导航添加类名
    var nav = $("header"); //得到导航对象
    var win = $(window); //得到窗口对象
    var sc = $(document);//得到document文档对象。
    win.scroll(function () {
        if (sc.scrollTop() >= 100) {
            nav.addClass("on");
        } else {
            nav.removeClass("on");
        }
    });

    //移动端展开nav
    $('#navToggle').on('click', function () {
        $('.m_nav').addClass('open');
    });
    //关闭nav
    $('.m_nav .top .closed').on('click', function () {
        $('.m_nav').removeClass('open');
    });

    //二级导航  移动端
    $(".m_nav .ul li").click(function () {
        $(this).children("div.dropdown_menu").slideToggle('slow');
        $(this).siblings('li').children('.dropdown_menu').slideUp('slow');
    });

});

// 选择Demo Data数据以及故障类型
function change() {
    var x = document.getElementById("first");
    var y = document.getElementById("second");
    y.options.length = 0; // 清除second下拉框的所有内容
    if (x.selectedIndex == 0) {
        y.options.add(new Option("Health(20Hz&10KHz)", "Health(20Hz&10KHz)", false, true));  // 默认选中health城市
        y.options.add(new Option("Inner(20Hz&10KHz)", "Inner(20Hz&10KHz)"));
        y.options.add(new Option("Outer(20Hz&10KHz)", "Outer(20Hz&10KHz)"));
        y.options.add(new Option("Ball(20Hz&10KHz)", "Ball(20Hz&10KHz)"));
    }
    if (x.selectedIndex == 1) {
        y.options.add(new Option("Step1(2000&20KHz)", "Step1(2000&20KHz)", false, true)); // 默认选中health城市
        y.options.add(new Option("Step2(2000&20KHz)", "Step2(2000&20KHz)"));
        y.options.add(new Option("Step3(2000&20KHz)", "Step132000&20KHz)"));
        y.options.add(new Option("Step4(2000&20KHz)", "Step4(2000&20KHz)"));
    }
    if (x.selectedIndex == 2) {
        y.options.add(new Option("Health(1796&12KHz)", "Health(1796&12KHz)", false, true)); // 默认选中health城市
        y.options.add(new Option("Outer(0.007-1-&1773&12KHz)", "Outer(0.007-1-&1773&12KHz)"));
        y.options.add(new Option("Inner(0.007-1-&1772&12KHz)", "Inner(0.007-1-&1772&12KHz)"));
        y.options.add(new Option("Ball(0.007-1-&1772&12KHz)", "Ball(0.007-1-&1772&12KHz)"));
    }
    /*在第一个数据源选中之后必须更新一下，下面的第二个数据源才会发生改变*/
    $('#second').selectpicker('refresh');
}

/*将选择的Demo Data输出*/
$(function () {
    $("#save").click(function () {
        /*分别读取g(数据源),h故障类型*/
        var g = $("#first").val();
        var h = $("#second").val();
        /*向服务器发送get请求，请求地址为/demodata/  */
        $.get("/demodata/", {"g": g.toString(), "h": h.toString(),}, function (r) {
            $('#choose1').attr("value", r);
            alert("The Data is Read!");
        });
    });
});

/*将选择的Local Data输出*/
$(function () {
    $("#saves").click(function () {
        var m = 0;
        /*向服务器发送get请求，请求地址为/change/  */
        $.get("/localchange/", {"m": m.toString()}, function (r) {
            $('#choose1').attr("value", r);
        });
    })
});

// 本地文件及参数的上传
function UpladFile() {
    alert("Success!");
    var fileObj = document.getElementById("fileField").files[0]; // js 获取文件对象
    var a = fileObj.name;
    /*下面的function是个局部函数*/
    $(function () {
        $("#saves").click(function () {
            /*分别读取a(读取本地文件的名字),b(是否有时间戳),c(采样频率),d(电机转速),e(纵坐标值),f(是否有时间戳)*/
            var b = $('#checkbox2').is(':checked');
            var c = $("#value1").val();
            var d = $("#value2").val();
            var e = $("#value3").val();
            $("#checkbox2").prop("checked", false);
            /*向服务器发送get请求，请求地址为/localdata/  */
            $.get("/localdata/", {
                "a": a.toString(),
                "b": b.toString(),
                "c": c.toString(),
                "d": d.toString(),
                "e": e.toString(),
            }, function (ret) {
                alert(ret)
            });
        });
    });
}

/*对原始数据的滤波处理方法，后期可以将滤波方法回传到后台一下(也可以在后台自行判断)*/
function filter(id) {
    var name = id;
    // console.log(name);
    $('#choose2').attr("value", name.toString());
}

/*选择特征并回传，注意这里只能选一个特征回传，不再是复选框*/
function feature(id) {
    var i = id;
    $('#choose3').attr("value", i);
    /*确定i、j值后将值回传给views.py函数（后台处理）其中i表示选取的特征;j表示是否傅里叶变换*/
    $.get("/feature/", {"i": i.toString()/*, "j": j.toString()*/}, function (r) {
        var strJSON = r;
        var obj = new Function("return" + strJSON)();//转换后的JSON对象
        feature = obj.feature;
        $('#choose4').attr("value", feature);
        /*以上都是读取json格式的信息*/
    });
}

/*选取的轴承故障判断方法，后期将判断方法回传到后台*/
function Diagnosis(id) {
    var name = id;
    // console.log(name);
    $('#choose5').attr("value", name.toString());
}

/*选取的绘制图的方法，包括时域和频域*/
function times(id) {
    var i = id;
    $('#choose6').attr("value", i.toString());
    /*确定i值后将值回传给views.py函数（后台处理）其中i表示选取时域或频域绘制*/
    $.get("/times/", {"i": i.toString()}, function (r) {
        var strJSON = r;
        var obj = new Function("return" + strJSON)();//转换后的JSON对象
        timestamp = obj.x;
        value = obj.y;
        legend = obj.legend;
        xlabel = obj.xlabel;
        ylabel = obj.ylabel;
        /*以上都是读取json格式的信息*/
        plot(timestamp, value, legend, xlabel, ylabel);
    });
}

function plot(timestamp, value, legend, xlabel, ylabel) {
    var dom = document.getElementById("container");
    <!--返回对拥有指定 container 的第一个对象的引用 -->
    var myChart = echarts.init(dom);
    <!-- {}表示定义一个对象或一个函数 -->
    option = null;
    var xAxisData = [];
    var data = [];
    for (var i = 0; i < (timestamp.length); i++) {
        xAxisData.push(timestamp[i]);
        <!-- xAxisData.push表示动态写入数据 -->
        data.push(value[i]);
    }
    option = {
        title: {
            /*text: '轴承故障数据柱状图动画延迟'*/
        },
        legend: {
            data: [legend],
            align: 'left',
            textStyle: {
                color: "#fff"
            }

        },
        toolbox: {
            // toolbox表示工具栏  y: 'bottom',
            feature: {
                magicType: {
                    <!-- magicType：动态类型切换。type->这是个数组，启用的动态类型，包括'line'（切换为折线图）, 'bar'（切换为柱状图）, 'stack'（切换为堆叠模式）, 'tiled'（切换为平铺模式）-->
                    type: ['stack', 'tiled']
                },
                dataView: {},
                saveAsImage: {
                    pixelRatio: 2   // 像素比例
                }
            }
        },
        tooltip: {}, //提示框组件
        xAxis: {
            data: xAxisData,
            name: xlabel,
            silent: false,  // 无声
            splitLine: {  //分割线
                show: false
            },
            axisLine: {
                lineStyle: {
                    color: "#fff",
                }
            }
        },
        yAxis: {
            name: ylabel,
            axisLine: {
                lineStyle: {
                    color: "#fff",
                }
            }
        },
        series: {
            name: legend,
            type: 'bar',
            data: data,
            animationDelay: function (idx) {  //设置初始ECharts动画的时长，支持回调函数，可以通过每个数据返回不同的 delay 时间实现更戏剧的初始动画效果：
                return idx * 10;
            },
            itemStyle: {
                normal: {
                    color: '#4ad2ff'
                }
            },
            axisLine: {
                lineStyle: {
                    color: "#fff",
                }
            }
        },
        animationEasing: 'elasticOut',    //伸缩缓冲（ElasticEase）：创建表示弹簧在停止前来回振荡的动画
        animationDelay: function (idx) {  //支持回调函数，可以通过每个数据返回不同的 delay 时间实现更戏剧的更新动画效果：
            return idx * 5;
        }
    };
    if (option && typeof option === "object") {
        myChart.setOption(option, true);
    }
}

/*下面的function是个局部函数*/
$(function () {
    $("#threeimage").click(function () {
        /*分别读取m(采样频率),n(分组数)*/
        var m = $("#3d1").val();
        var n = $("#3d2").val();
        var o = $("#third").val();
        $('#choose6').attr("value", "3DMap");
        /*向服务器发送get请求，请求地址为/bar3d/  */
        $.get("/bar3d/", {
            "m": m.toString(),
            "n": n.toString(),
            "o": o.toString(),
        }, function (r) {
            var strJSON = r;
            var obj = new Function("return" + strJSON)();//转换后的JSON对象
            Frequencydomain = obj.x;
            Acceleration = obj.y;
            n = obj.z;
            Max = obj.Max;
            Min = obj.Min;
            plot3d(Frequencydomain, Acceleration, n, Max, Min);
        });
    });
});

function plot3d(Frequencydomain, Acceleration, n, Max, Min) {
    // console.log(Frequencydomain);
    // console.log(Acceleration);
    //其中n表示每组有多少个数据
    var number = Math.ceil((Frequencydomain.length) / n);
    console.log(number);
    var data = [];
    var k = 0;
    for (var i = 0; i < n; i++) {
        for (var j = 0; j < number; j++) {
            data.push([i, Frequencydomain[k], Acceleration[k]]);
            k = k + 1;
        }
    }
    $.getScript('../static/js/simplex.js').done(function () {
        var dom = document.getElementById("containers");
        var myChart = echarts.init(dom);
        option = null;
        /*console.log(data);*/
        myChart.setOption(option = {
                title: {
                    text: 'Time-frequency domain waterfall',
                    textAlign: 'left',
                    textStyle: {
                        fontSize: 30,
                        padding: 10,
                        color: '#FFF',
                    },
                },
                backgroundColor: '#5B5B5B',
                visualMap: {
                    show: true,//如果为true左下角有一个视觉小地图
                    min: Min,
                    max: Max,
                    inRange: {
                        color: ['#313695', '#4575b4', '#74add1', '#abd9e9', '#e0f3f8', '#ffffbf', '#fee090', '#fdae61', '#f46d43', '#d73027', '#a50026']
                    }
                },
                xAxis3D: {
                    type: 'value',
                    name: 'X：Time'
                    // splitNumber: 10                      // 数值轴用，分割段数，默认为5
                },
                yAxis3D: {
                    type: 'value',
                    splitNumber: 10,                      // 数值轴用，分割段数，默认为5
                    name: 'Y：Hz',
                },
                zAxis3D: {
                    type: 'value',
                    name: 'Z：g',
                    max: Max,
                    min: 0
                },
                grid3D: {
                    axisLine: {
                        lineStyle: {color: '#fff'}
                    },
                    axisPointer: {
                        lineStyle: {color: '#fff'}
                    },
                    viewControl: {
                        autoRotate: true   //设置图形自动旋转
                    },
                    light: {
                        main: {
                            shadow: true,
                            quality: 'ultra',
                            intensity: 1.5
                        }
                    }
                },
                series: [{
                    type: 'bar3D',
                    data: data,
                    shading: 'lambert',
                    label: {
                        formatter: function (param) {
                            return param.value[2].toFixed(1);
                        }
                    }
                }]
            }
        );
        if (option && typeof option === "object") {
            myChart.setOption(option, true);
        }
    });
}
